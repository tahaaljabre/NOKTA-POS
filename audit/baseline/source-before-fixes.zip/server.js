const http = require('http');
const { Server } = require('socket.io');
const config = require('./src/config/app.config');
const { initDatabase } = require('./src/database/db');
const { createApp } = require('./src/app');
const { initSocket } = require('./src/socket/socket.handler');

async function startServer() {
  // 1. Initialize SQLite Database & Migrations
  await initDatabase();

  // 2. Create Express App & HTTP Server
  const app = createApp();
  const server = http.createServer(app);

  // 3. Initialize Socket.IO
  const io = new Server(server, {
    cors: { origin: false }
  });
  initSocket(io);

  // 4. Start Listening
  server.listen(config.port, config.host, () => {
    console.log(`\n========================================`);
    console.log(`  🍽️ POS Server: http://${config.host}:${config.port}`);
    console.log(`  🔐 Initial setup: create the administrator account in the browser`);
    console.log(`  📱 Responsive Multi-device Architecture`);
    console.log(`========================================\n`);
  });
}

if (require.main === module) {
  startServer().catch(err => {
    console.error('Server Startup Failed:', err);
    process.exit(1);
  });
}

module.exports = { startServer };
