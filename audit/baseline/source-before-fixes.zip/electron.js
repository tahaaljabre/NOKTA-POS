const { app, BrowserWindow, dialog, ipcMain } = require('electron');
const path = require('path');
const { startServer } = require('./server.js');
const config = require('./src/config/app.config');

let mainWindow;

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    title: 'NOKTA POS - Desktop',
    icon: path.join(__dirname, 'public/favicon.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.setMenuBarVisibility(false);
  
  try {
    console.log('Starting local server for Electron...');
    await startServer();
    console.log('Local server started. Loading UI...');
    mainWindow.loadURL(`http://localhost:${config.port}`);
  } catch (err) {
    console.error('Failed to start server:', err);
    dialog.showErrorBox('Server Error', 'Failed to start the local server: ' + err.message);
    app.quit();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  // Windows lists USB, Bluetooth, and installed network printers together.
  // Expose only this read-only inventory to the renderer.
  ipcMain.handle('nokta:printers:list', async () => {
    const window = BrowserWindow.getFocusedWindow() || mainWindow;
    if (!window) return [];
    const printers = await window.webContents.getPrintersAsync();
    return printers.map(printer => ({
      id: printer.name,
      name: printer.displayName || printer.name,
      device: printer.name,
      type: printer.isDefault ? 'default' : 'system',
      status: printer.status || 0,
      isDefault: !!printer.isDefault
    }));
  });
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // In a POS, closing the window usually means shutting down the server.
    app.quit();
    process.exit(0);
  }
});
