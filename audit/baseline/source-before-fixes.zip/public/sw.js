const CACHE_NAME = 'pos-v53';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/style.css',
  '/i18n.js',
  '/manifest.json',
  '/js/app.js',
  '/js/menu.js',
  '/js/orders.js',
  '/js/tables.js',
  '/js/employees.js',
  '/js/settings.js',
  '/js/invoices.js',
  '/js/daily-closing.js',
  '/js/sales.js',
  '/js/audit.js',
  '/js/reports.js',
  '/js/admin.js'
];

const API_CACHE = 'pos-api-v2';
const SYNC_QUEUE = 'pos-sync-queue';

// ===== Install =====
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

// ===== Activate =====
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE_NAME && k !== API_CACHE).map(k => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

// ===== Fetch - Network First for API, Cache First for Static =====
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // API requests - Network First with cache fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          // Cache GET responses for offline
          if (event.request.method === 'GET') {
            const clone = response.clone();
            caches.open(API_CACHE).then(cache => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // Socket.IO - network only
  if (url.pathname.startsWith('/socket.io/')) return;

  // Static assets - Cache First
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      });
    }).catch(() => {
      // Offline fallback
      if (event.request.destination === 'document') {
        return caches.match('/index.html');
      }
    })
  );
});

// ===== Background Sync =====
self.addEventListener('sync', event => {
  if (event.tag === 'sync-orders') {
    event.waitUntil(syncOfflineOrders());
  }
});

async function syncOfflineOrders() {
  try {
    const db = await openDB();
    const tx = db.transaction('offline-orders', 'readonly');
    const store = tx.objectStore('offline-orders');
    const orders = await getAllFromStore(store);

    if (orders.length === 0) return;

    const response = await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(orders[0]?.auth_token ? { Authorization: `Bearer ${orders[0].auth_token}` } : {}) },
      body: JSON.stringify({
        device_id: await getDeviceId(),
        orders: orders,
        last_sync: await getLastSyncTime()
      })
    });

    if (response.ok) {
      const result = await response.json();
      // Clear synced orders
      const deleteTx = db.transaction('offline-orders', 'readwrite');
      const deleteStore = deleteTx.objectStore('offline-orders');
      await clearStore(deleteStore);
      await setLastSyncTime(result.server_time);

      // Notify client
      self.clients.matchAll().then(clients => {
        clients.forEach(client => client.postMessage({ type: 'SYNC_COMPLETE', result }));
      });
    }
  } catch (e) {
    console.error('Sync failed:', e);
  }
}

// IndexedDB helpers for offline queue
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('pos-offline', 1);
    request.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('offline-orders')) {
        db.createObjectStore('offline-orders', { keyPath: 'local_id', autoIncrement: true });
      }
    };
    request.onsuccess = e => resolve(e.target.result);
    request.onerror = e => reject(e.target.error);
  });
}

function getAllFromStore(store) {
  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function clearStore(store) {
  return new Promise((resolve, reject) => {
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function getDeviceId() {
  let id = localStorage.getItem('device_id');
  if (!id) {
    id = 'device_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('device_id', id);
  }
  return id;
}

async function getLastSyncTime() {
  return localStorage.getItem('last_sync') || '1970-01-01';
}

async function setLastSyncTime(time) {
  localStorage.setItem('last_sync', time);
}

// ===== Listen for messages from client =====
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  if (event.data && event.data.type === 'FORCE_SYNC') {
    syncOfflineOrders();
  }
});
