const kitchenToken = localStorage.getItem('pos_kitchen_token') || '';
// The API and real-time socket are both protected by the signed login token.
const socket = io({ auth: { token: kitchenToken } });
let hasLoadedOrders = false;
let knownOrderIds = new Set();

function kitchenHeaders(json = false) {
  const headers = {};
  if (json) headers['Content-Type'] = 'application/json';
  if (kitchenToken) headers.Authorization = `Bearer ${kitchenToken}`;
  return headers;
}

// State
let kdsOrders = [];
let audioContext;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  if (typeof applyTranslations === 'function') applyTranslations();
  initClock();
  fetchActiveOrders();
  initAudio();
  // A safety net for a temporary network interruption. Normal updates arrive
  // immediately through Socket.IO; this picks up anything missed after reconnect.
  setInterval(() => fetchActiveOrders(false), 10000);
});

function initClock() {
  const clockEl = document.getElementById('kds-clock');
  setInterval(() => {
    const now = new Date();
    clockEl.textContent = now.toLocaleTimeString('en-US', { hour12: false });
  }, 1000);
}

// User gesture needed for audio
function initAudio() {
  const btn = document.getElementById('btn-enable-sound');
  if (btn) {
    btn.style.display = 'block';
    btn.onclick = () => {
      if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === 'suspended') audioContext.resume();
      playNotification();
      btn.textContent = '🔊 الصوت مفعل';
      btn.style.opacity = '0.75';
    };
  }
  document.body.addEventListener('click', () => {
    if (!audioContext) {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
  }, { once: true });
}

function playNotification() {
  // A short built-in beep works even if the external sound file is blocked.
  try {
    if (audioContext) {
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.frequency.value = 880;
      gain.gain.setValueAtTime(0.14, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.35);
      oscillator.connect(gain).connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.35);
    }
  } catch (e) { console.warn('Kitchen beep failed', e); }
  const audio = document.getElementById('notification-sound');
  if (audio) {
    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(e => {
        console.log('Audio play prevented by browser', e);
        const btn = document.getElementById('btn-enable-sound');
        if (btn) {
          btn.style.display = 'block';
          btn.onclick = () => {
            audio.play();
            btn.style.display = 'none';
          };
        }
      });
    }
  }
}

// Socket Listeners
socket.on('order:created', () => fetchActiveOrders(true));
socket.on('order:updated', () => fetchActiveOrders());
socket.on('order:items_changed', () => fetchActiveOrders());
socket.on('kds:new_order', () => {
  fetchActiveOrders(true);
});

async function fetchActiveOrders(isNew = false) {
  try {
    const res = await fetch('/api/orders?status=active&with_items=1', {
      headers: kitchenHeaders()
    });
    if (!res.ok) throw new Error(res.status === 401 ? 'يرجى تسجيل الدخول من شاشة نقطة البيع أولاً' : `HTTP ${res.status}`);
    const data = await res.json();
    
    // Filter out orders that don't have items or are already "ready" in KDS
    // For now, let's assume any active order that is not "ready" is shown.
    // If attributes has kds_status == 'ready', we hide it from KDS? No, maybe show it with a different color.
    
    // For now, let's just show all active orders
    kdsOrders = data.filter(order => {
      try {
        const attr = JSON.parse(order.attributes || '{}');
        return attr.kds_status !== 'ready'; // Hide ready orders from active KDS view? Or keep them?
      } catch (e) {
        return true;
      }
    });
    
    const incomingIds = new Set(kdsOrders.map(order => String(order.id)));
    const hasNewOrder = hasLoadedOrders && [...incomingIds].some(id => !knownOrderIds.has(id));
    knownOrderIds = incomingIds;
    hasLoadedOrders = true;
    renderTickets();
    
    if (isNew || hasNewOrder) {
      playNotification();
    }
  } catch (err) {
    console.error('Failed to fetch orders for KDS', err);
    const container = document.getElementById('kds-container');
    if (container) container.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:#a11;padding:50px;font-size:1.1rem;">${err.message}</div>`;
  }
}

async function markOrderReady(orderId) {
  try {
    // We can update the order attributes via a new API or just use the existing PUT /api/orders/:id
    // But we don't want to overwrite the whole order. Let's fetch it, update attributes, save.
    const res = await fetch(`/api/orders/${orderId}`, { headers: kitchenHeaders() });
    if (!res.ok) throw new Error('تعذر جلب الطلب');
    const order = await res.json();
    
    let attr = {};
    try { attr = JSON.parse(order.attributes || '{}'); } catch(e) {}
    
    attr.kds_status = 'ready';
    
    const updateRes = await fetch(`/api/orders/${orderId}`, {
      method: 'PUT',
      headers: kitchenHeaders(true),
      body: JSON.stringify({
        status: order.status,
        type: order.type,
        table_id: order.table_id,
        items: order.items,
        attributes: JSON.stringify(attr)
      })
    });
    
    if (updateRes.ok) {
      fetchActiveOrders();
    } else {
      const errText = await updateRes.text();
      alert('فشل تحديث الطلب: ' + errText);
    }
  } catch (err) {
    console.error('Error marking order as ready', err);
    alert('حدث خطأ في الشبكة أو السيرفر');
  }
}

function renderTickets() {
  const container = document.getElementById('kds-container');
  container.innerHTML = '';
  
  if (kdsOrders.length === 0) {
    container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: #888; padding: 50px; font-size: 1.5rem;">${typeof t === 'function' ? t('kds_no_orders') : 'لا توجد طلبات نشطة للمطبخ'}</div>`;
    return;
  }
  
  // Sort by created_at (oldest first)
  const sorted = [...kdsOrders].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  
  sorted.forEach(order => {
    let attr = {};
    try { attr = JSON.parse(order.attributes || '{}'); } catch(e) {}
    
    // Only show if it's sent to kitchen. Let's assume all active orders are sent to kitchen by default,
    // OR we only show orders where attr.kds_sent === true.
    // The user didn't specify, so let's just show all active orders.
    
    const ticket = document.createElement('div');
    ticket.className = `kds-ticket type-${order.type}`;
    
    const time = new Date(order.created_at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    
    let title = order.type === 'dine_in' ? `${typeof t === 'function' ? t('kds_table') : 'طاولة'} ${order.table_id || '?'}` : (order.type === 'takeaway' ? (typeof t === 'function' ? t('takeaway') : 'سفري') : (typeof t === 'function' ? t('delivery') : 'توصيل'));
    
    let itemsHtml = (order.items || []).map(item => `
      <li class="kds-ticket-item" onclick="this.classList.toggle('done')">
        <div>
          <span>${item.item_name}</span>
          ${item.note ? `<span class="note">${item.note}</span>` : ''}
        </div>
        <span class="qty">x${item.quantity}</span>
      </li>
    `).join('');
    
    ticket.innerHTML = `
      <div class="kds-ticket-header">
        <h3>#${order.invoice_number || order.id} - ${title}</h3>
        <div>
          <span class="kds-ticket-type">${order.type === 'dine_in' ? (typeof t === 'function' ? t('dine_in') : 'محلي') : (order.type === 'takeaway' ? (typeof t === 'function' ? t('takeaway') : 'سفري') : (typeof t === 'function' ? t('delivery') : 'توصيل'))}</span>
          <span class="kds-ticket-time">${time}</span>
        </div>
      </div>
      <ul class="kds-ticket-items">
        ${itemsHtml}
      </ul>
      <div class="kds-ticket-footer">
        <button class="btn-ready" onclick="markOrderReady(${order.id})">${typeof t === 'function' ? t('kds_ready') : 'جاهز ✅'}</button>
      </div>
    `;
    
    container.appendChild(ticket);
  });
}
