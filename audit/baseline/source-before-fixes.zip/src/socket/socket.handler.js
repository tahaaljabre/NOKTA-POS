let ioInstance = null;
const { verifyToken } = require('../middleware/auth.middleware');

function initSocket(io) {
  ioInstance = io;
  io.use((socket, next) => verifyToken(socket.handshake.auth && socket.handshake.auth.token) ? next() : next(new Error('Authentication required')));
  io.on('connection', socket => {
    socket.on('disconnect', () => {});
  });
}

function emitEvent(event, data) {
  if (ioInstance) {
    ioInstance.emit(event, data);
  }
}

function getIo() {
  return ioInstance;
}

module.exports = { initSocket, emitEvent, getIo };
