const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./config/app.config');

// Import modular routes
const authRoutes = require('./routes/auth.routes');
const categoriesRoutes = require('./routes/categories.routes');
const itemsRoutes = require('./routes/items.routes');
const modifiersRoutes = require('./routes/modifiers.routes');
const tablesRoutes = require('./routes/tables.routes');
const ordersRoutes = require('./routes/orders.routes');
const invoicesRoutes = require('./routes/invoices.routes');
const customersRoutes = require('./routes/customers.routes');
const inventoryRoutes = require('./routes/inventory.routes');
const shiftsRoutes = require('./routes/shifts.routes');
const dailyClosingRoutes = require('./routes/daily-closing.routes');
const reportsRoutes = require('./routes/reports.routes');
const employeesRoutes = require('./routes/employees.routes');
const settingsRoutes = require('./routes/settings.routes');
const syncRoutes = require('./routes/sync.routes');
const backupRoutes = require('./routes/backup.routes');
const { requirePermission } = require('./middleware/auth.middleware');

function createApp() {
  const app = express();

  // Basic Middlewares
  app.use(cors({ origin: false }));
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Security Headers against Clickjacking, MIME sniffing, and XSS
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.setHeader('Referrer-Policy', 'same-origin');
    if (req.url.match(/\.(html|js|css)$/)) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
    if (req.headers['x-employee-name']) {
      try {
        req.headers['x-employee-name'] = decodeURIComponent(req.headers['x-employee-name']);
      } catch (e) {}
    }
    next();
  });

  // Login Brute-Force Rate Limiter (max five attempts per minute per IP)
  const loginAttempts = new Map();
  app.use('/api/auth/login', (req, res, next) => {
    const ip = req.ip || req.connection.remoteAddress || 'unknown';
    const now = Date.now();
    const record = loginAttempts.get(ip) || { count: 0, firstAttempt: now };

    if (now - record.firstAttempt > 60000) {
      record.count = 0;
      record.firstAttempt = now;
    }

    record.count++;
    loginAttempts.set(ip, record);

    if (record.count > 5) {
      return res.status(429).json({ error: 'Too many attempts. Please wait one minute. (محاولات كثيرة - يرجى الانتظار)' });
    }
    next();
  });

  // Serve static assets from public/
  app.use(express.static(config.publicDir));

  // Mount API Modules
  app.use('/api/auth', authRoutes);
  app.use('/api/categories', categoriesRoutes);
  app.use('/api/items', itemsRoutes);
  app.use('/api/modifiers', modifiersRoutes);
  app.use('/api/tables', tablesRoutes);
  app.use('/api/orders', ordersRoutes);
  app.use('/api/invoices', invoicesRoutes);
  app.use('/api/customers', customersRoutes);
  app.use('/api/inventory', inventoryRoutes);
  app.use('/api/shifts', shiftsRoutes);
  app.use('/api/daily-closings', dailyClosingRoutes);
  app.use('/api/reports', reportsRoutes);
  app.use('/api/employees', employeesRoutes);
  app.use('/api/settings', settingsRoutes);
  app.get('/api/audit', requirePermission('audit'), settingsRoutes.handleAuditGet);
  app.use('/api/sync', syncRoutes);
  app.use('/api/backup', backupRoutes);

  // Single Page App Fallback for GET requests
  app.get('*', (req, res) => {
    res.sendFile(path.join(config.publicDir, 'index.html'));
  });

  // Global Error Handler
  app.use((err, req, res, next) => {
    console.error('Unhandled API Error:', err);
    res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
  });

  return app;
}

module.exports = { createApp };
