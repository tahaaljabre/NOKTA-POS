const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { requireAuthenticated, requirePermission } = require('../middleware/auth.middleware');
router.use(requireAuthenticated);

router.get('/', requirePermission('view_invoices'), (req, res) => {
  const { date, employee_id, search, page, limit } = req.query;
  let sql = `SELECT o.*, t.number as table_number, t.name as table_name, c.name as customer_name FROM orders o LEFT JOIN "tables" t ON o.table_id=t.id LEFT JOIN customers c ON o.customer_id=c.id WHERE o.is_deleted=0 AND o.status IN ('completed','cancelled')`;
  const p = [];
  if (date) { sql += " AND DATE(o.created_at)=?"; p.push(date); }
  if (employee_id) { sql += ' AND o.employee_id=?'; p.push(employee_id); }
  if (search) { sql += ' AND o.invoice_number=?'; p.push(parseInt(search)); }
  sql += ' ORDER BY o.invoice_number DESC';
  
  const lim = parseInt(limit) || 100;
  const off = ((parseInt(page) || 1) - 1) * lim;
  sql += ` LIMIT ${lim} OFFSET ${off}`;
  
  const rows = db.prepare(sql).all(...p);
  const countSql = "SELECT COUNT(*) as total FROM orders WHERE is_deleted=0 AND status IN ('completed','cancelled')";
  const total = db.prepare(countSql).get();
  res.json({ orders: rows, total: total ? total.total : 0 });
});

module.exports = router;
