const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { logAudit } = require('../middleware/audit.middleware');
const { emitEvent } = require('../socket/socket.handler');
const { checkPerm, requirePermission } = require('../middleware/auth.middleware');
router.use(requirePermission('pos'));

function getNextInvoiceNumber() {
  const row = db.prepare("SELECT value FROM settings WHERE key='next_invoice_number'").get();
  const num = row ? parseInt(row.value) || 1 : 1;
  db.prepare("UPDATE settings SET value=? WHERE key='next_invoice_number'").run(String(num + 1));
  return num;
}

function recalcOrderTotal(orderId) {
  try {
    const o = db.prepare('SELECT discount_percent, discount_amount, tax_percent FROM orders WHERE id=?').get(orderId);
    if (!o) return 0;
    const items = db.prepare('SELECT price, quantity, discount_amount FROM order_items WHERE order_id=?').all(orderId);
    let subtotal = 0;
    items.forEach(i => {
      const price = parseFloat(i.price) || 0;
      const qty = parseInt(i.quantity) || 1;
      const itemDisc = parseFloat(i.discount_amount) || 0;
      subtotal += (price * qty) - itemDisc;
    });
    subtotal = Math.round(subtotal * 100) / 100;
    
    const discPct = (parseFloat(o.discount_percent) || 0) / 100;
    const discAmt = parseFloat(o.discount_amount) || 0;
    const afterDisc = Math.max(0, (subtotal * (1 - discPct)) - discAmt);
    
    const taxPct = (parseFloat(o.tax_percent) || 0) / 100;
    const taxAmt = Math.round((afterDisc * taxPct) * 100) / 100;
    const total = Math.round((afterDisc + taxAmt) * 100) / 100;

    db.prepare('UPDATE orders SET subtotal=?, tax_amount=?, total=? WHERE id=?').run(subtotal, taxAmt, total, orderId);
    return total;
  } catch(e) {
    console.error('Recalc order total error:', e.message);
    return 0;
  }
}

// GET active/filtered orders
router.get('/', (req, res) => {
  const { status, date, employee_id, not_deleted, with_items } = req.query;
  let sql = 'SELECT o.*, t.number as table_number, t.name as table_name, c.name as customer_name, c.phone as customer_phone FROM orders o LEFT JOIN "tables" t ON o.table_id=t.id LEFT JOIN customers c ON o.customer_id=c.id WHERE 1=1';
  const p = [];
  if (status) { sql += ' AND o.status=?'; p.push(status); }
  if (date) { sql += " AND DATE(o.created_at)=?"; p.push(date); }
  if (employee_id) { sql += ' AND o.employee_id=?'; p.push(employee_id); }
  if (not_deleted !== '0') { sql += ' AND o.is_deleted=0'; }
  sql += ' ORDER BY o.id DESC';
  const orders = db.prepare(sql).all(...p);

  if (with_items === '1' && orders.length > 0) {
    const orderIds = orders.map(o => o.id);
    const placeholders = orderIds.map(() => '?').join(',');
    const allItems = db.prepare(`
      SELECT oi.*, i.name as item_name, i.name_en as item_name_en 
      FROM order_items oi 
      LEFT JOIN items i ON oi.item_id=i.id 
      WHERE oi.order_id IN (${placeholders})
    `).all(...orderIds);

    const itemMap = {};
    allItems.forEach(item => {
      if (!itemMap[item.order_id]) itemMap[item.order_id] = [];
      itemMap[item.order_id].push(item);
    });

    orders.forEach(o => {
      o.items = itemMap[o.id] || [];
    });
  }

  res.json(orders);
});

// GET single order with items
router.get('/:id', (req, res) => {
  const order = db.prepare('SELECT o.*, t.number as table_number, t.name as table_name, c.name as customer_name, c.phone as customer_phone FROM orders o LEFT JOIN "tables" t ON o.table_id=t.id LEFT JOIN customers c ON o.customer_id=c.id WHERE o.id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  const items = db.prepare('SELECT oi.*, i.name as item_name, i.name_en as item_name_en, i.image as item_image FROM order_items oi LEFT JOIN items i ON oi.item_id=i.id WHERE oi.order_id=?').all(req.params.id);
  res.json({ ...order, items });
});

// POST Create Order (Atomic single-call support)
router.post('/', (req, res) => {
  try {
    let {
      table_id, customer_id, type, note, employee_id, employee_name,
      discount_percent, discount_amount, payment_method, items, total, status, attributes,
      station_id, floor, offline_id
    } = req.body;

    employee_id = req.currentUser.id;
    employee_name = req.currentUser.name;
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'Order must contain at least one item' });
    if (!['dine_in', 'takeaway', 'delivery'].includes(type || 'dine_in')) return res.status(400).json({ error: 'Invalid order type' });
    if (!['active', 'completed'].includes(status || 'active')) return res.status(400).json({ error: 'Invalid order status' });
    items = items.map(item => {
      const product = db.prepare('SELECT id, price FROM items WHERE id=? AND active=1').get(item.item_id);
      const quantity = Number(item.quantity);
      if (!product || !Number.isFinite(quantity) || quantity <= 0 || quantity > 1000) throw new Error('Invalid order item');
      return { ...item, item_id: product.id, quantity, price: product.price, discount_amount: 0 };
    });
    const invoiceNumber = getNextInvoiceNumber();
    const orderStatus = status || 'active';
    const discPct = parseFloat(discount_percent) || 0;
    const discAmt = parseFloat(discount_amount) || 0;
    const payMethod = payment_method || 'cash';
    const attrStr = typeof attributes === 'object' ? JSON.stringify(attributes) : (attributes || '{}');

    const taxSetting = db.prepare("SELECT value FROM settings WHERE key='tax_rate'").get();
    const defaultTaxRate = taxSetting ? parseFloat(taxSetting.value) || 0 : 0;

    // Concurrency check: if table is requested and already occupied by an active order, notify or assign
    if (table_id && orderStatus === 'active') {
      const tb = db.prepare('SELECT status, current_order_id FROM "tables" WHERE id=?').get(table_id);
      if (tb && tb.status === 'occupied' && tb.current_order_id) {
        // Table already has active order
      }
    }

    const info = db.prepare(`
      INSERT INTO orders (
        invoice_number, table_id, customer_id, type, status, total, discount_percent, discount_amount,
        tax_percent, payment_method, note, employee_id, employee_name, attributes, station_id, floor, offline_id, completed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
        invoiceNumber, table_id || null, customer_id || null, type || 'dine_in', orderStatus, 0,
      discPct, discAmt, defaultTaxRate, payMethod, note || '', employee_id || null, employee_name || '', attrStr,
      station_id || 'cashier_main', floor || 1, offline_id || '',
      orderStatus === 'completed' ? new Date().toISOString() : null
    );
    const orderId = info.lastInsertRowid;

    if (table_id && orderStatus === 'active') {
      db.prepare('UPDATE "tables" SET status="occupied", current_order_id=? WHERE id=?').run(orderId, table_id);
      emitEvent('table:updated', { table_id, status: 'occupied', order_id: orderId });
    }

    if (Array.isArray(items) && items.length > 0) {
      for (const item of items) {
        const modStr = Array.isArray(item.modifiers) ? JSON.stringify(item.modifiers) : (item.selected_modifiers || '[]');
        
        let modifierExtraPrice = 0;
        try {
          const parsedMods = JSON.parse(modStr);
          for (const m of parsedMods) {
            const modData = db.prepare('SELECT price_extra FROM modifiers WHERE id=?').get(m.id || m.modifier_id);
            if (modData) modifierExtraPrice += parseFloat(modData.price_extra) || 0;
          }
        } catch(e) {
          console.error('Error parsing modifiers:', e);
        }
        
        const finalItemPrice = (item.price || 0) + modifierExtraPrice;

        db.prepare('INSERT INTO order_items (order_id, item_id, quantity, note, price, discount_amount, selected_modifiers) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
          orderId, item.item_id, item.quantity || 1, item.note || '', finalItemPrice, item.discount_amount || 0, modStr
        );
      }
      recalcOrderTotal(orderId);
    }
    if (customer_id && orderStatus === 'completed') {
      const saved = db.prepare('SELECT total FROM orders WHERE id=?').get(orderId);
      const orderTotal = saved.total || 0;
      db.prepare('UPDATE customers SET points=points+?, total_spent=total_spent+?, total_orders=total_orders+1 WHERE id=?').run(Math.floor(orderTotal / 10), orderTotal, customer_id);
    }

    logAudit(employee_id, employee_name, 'create_order', 'orders', orderId, `Created Invoice #${invoiceNumber} (Total: ${total || 0}, Floor: ${floor || 1})`);
    
    // Broadcast real-time order creation event to all cashiers & waiters
    emitEvent('order:created', {
      orderId,
      invoice_number: invoiceNumber,
      table_id,
      type,
      total,
      employee_name,
      station_id: station_id || 'cashier_main',
      floor: floor || 1,
      items: items || []
    });

    const fullOrder = db.prepare('SELECT o.*, t.number as table_number, t.name as table_name FROM orders o LEFT JOIN "tables" t ON o.table_id=t.id WHERE o.id=?').get(orderId);
    const orderItems = db.prepare('SELECT oi.*, i.name as item_name, i.name_en as item_name_en FROM order_items oi LEFT JOIN items i ON oi.item_id=i.id WHERE oi.order_id=?').all(orderId);

    res.json({ id: orderId, invoice_number: invoiceNumber, ...fullOrder, items: orderItems });
  } catch (err) {
    console.error('Create order error:', err);
    res.status(500).json({ error: err.message });
  }
});

// PUT Update / Complete Order
router.put('/:id', (req, res) => {
  try {
    const { status, note, discount_percent, discount_amount, payment_method, paid_amount, change_amount, items, attributes } = req.body;
    const oldOrder = db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);
    if (!oldOrder) {
      return res.status(404).json({ error: 'Order not found' });
    }
    if (req.currentUser.role !== 'admin' && !req.currentUser.permissions.edit_orders && oldOrder.employee_id !== req.currentUser.id) return res.status(403).json({ error: 'You can only modify your own orders' });
    const oldItems = db.prepare('SELECT oi.*, i.name as item_name FROM order_items oi LEFT JOIN items i ON oi.item_id=i.id WHERE oi.order_id=?').all(req.params.id);

    const updateOrderTx = db.transaction(() => {
      let completedAt = null;
      if (status === 'completed' || status === 'cancelled') {
        completedAt = new Date().toISOString();
      }
      db.prepare(`
        UPDATE orders 
        SET status=COALESCE(?, status),
            note=COALESCE(?, note),
            discount_percent=COALESCE(?, discount_percent),
            discount_amount=COALESCE(?, discount_amount),
            payment_method=COALESCE(?, payment_method),
            paid_amount=COALESCE(?, paid_amount),
            change_amount=COALESCE(?, change_amount),
            completed_at=COALESCE(?, completed_at),
            attributes=COALESCE(?, attributes)
        WHERE id=?
      `).run(
        status, note, discount_percent, discount_amount, payment_method, paid_amount, change_amount, completedAt, attributes, req.params.id
      );

      // Update items if provided
      if (Array.isArray(items)) {
        db.prepare('DELETE FROM order_items WHERE order_id=?').run(req.params.id);
        for (const item of items) {
          const product = db.prepare('SELECT id, price FROM items WHERE id=? AND active=1').get(item.item_id);
          const quantity = Number(item.quantity);
          if (!product || !Number.isFinite(quantity) || quantity <= 0 || quantity > 1000) throw new Error('Invalid order item');
          const modStr = Array.isArray(item.modifiers) ? JSON.stringify(item.modifiers) : (item.selected_modifiers || '[]');
          
          let modifierExtraPrice = 0;
          try {
            const parsedMods = JSON.parse(modStr);
            for (const m of parsedMods) {
              const modData = db.prepare('SELECT price_extra FROM modifiers WHERE id=?').get(m.id || m.modifier_id);
              if (modData) modifierExtraPrice += parseFloat(modData.price_extra) || 0;
            }
          } catch(e) {
            console.error('Error parsing modifiers:', e);
          }
          
          const finalItemPrice = product.price + modifierExtraPrice;

          db.prepare('INSERT INTO order_items (order_id, item_id, quantity, note, price, discount_amount, selected_modifiers) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
            req.params.id, product.id, quantity, item.note || '', finalItemPrice, 0, modStr
          );
        }
      }

      if (status === 'completed' || status === 'cancelled') {
        const o = db.prepare('SELECT table_id FROM orders WHERE id=?').get(req.params.id);
        if (o && o.table_id) {
          db.prepare('UPDATE "tables" SET status="empty", current_order_id=NULL WHERE id=?').run(o.table_id);
          emitEvent('table:updated', { table_id: o.table_id, status: 'empty', order_id: null });
        }
      }
    });
    
    updateOrderTx();
    
    // 1. Revert previous inventory and customer points if old order was completed
    if (oldOrder.status === 'completed') {
      for (const item of oldItems) {
        const inv = db.prepare('SELECT id, quantity FROM inventory WHERE item_id=?').get(item.item_id);
        if (inv) {
          const newQty = inv.quantity + item.quantity;
          db.prepare('UPDATE inventory SET quantity=? WHERE id=?').run(newQty, inv.id);
          db.prepare('INSERT INTO stock_logs (inventory_id, type, quantity, previous_qty, new_qty, notes) VALUES (?, ?, ?, ?, ?, ?)').run(
            inv.id, 'refund', item.quantity, inv.quantity, newQty, `Order #${oldOrder.invoice_number} edit revert`
          );
        }
      }
      if (oldOrder.customer_id) {
        const orderTotal = oldOrder.total || 0;
        const pts = Math.floor(orderTotal / 10);
        db.prepare('UPDATE customers SET points = points - ?, total_spent = total_spent - ?, total_orders = total_orders - 1 WHERE id = ?').run(pts, orderTotal, oldOrder.customer_id);
      }
    }

    recalcOrderTotal(req.params.id);

    const newOrder = db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);
    const newItems = db.prepare('SELECT oi.*, i.name as item_name FROM order_items oi LEFT JOIN items i ON oi.item_id=i.id WHERE oi.order_id=?').all(req.params.id);

    // 2. Apply new inventory and customer points if new order is completed
    if (newOrder.status === 'completed') {
      for (const item of newItems) {
        const inv = db.prepare('SELECT id, quantity FROM inventory WHERE item_id=?').get(item.item_id);
        if (inv) {
          const newQty = inv.quantity - item.quantity;
          db.prepare('UPDATE inventory SET quantity=? WHERE id=?').run(newQty, inv.id);
          db.prepare('INSERT INTO stock_logs (inventory_id, type, quantity, previous_qty, new_qty, notes) VALUES (?, ?, ?, ?, ?, ?)').run(
            inv.id, 'sale', item.quantity, inv.quantity, newQty, `Order #${newOrder.invoice_number} edit apply`
          );
        }
      }
      if (newOrder.customer_id) {
        const orderTotal = newOrder.total || 0;
        const pts = Math.floor(orderTotal / 10);
        db.prepare('UPDATE customers SET points = points + ?, total_spent = total_spent + ?, total_orders = total_orders + 1 WHERE id = ?').run(pts, orderTotal, newOrder.customer_id);
      }
    }

    const auditAction = status === 'completed' ? 'complete_order' : (status === 'cancelled' ? 'cancel_order' : 'update_order');
    const oldSummary = `المجموع: ${oldOrder ? oldOrder.total : 0} | خصم: ${oldOrder ? oldOrder.discount_percent : 0}% | العناصر: ${oldItems.length}`;
    const newSummary = `المجموع: ${newOrder ? newOrder.total : 0} | خصم: ${newOrder ? newOrder.discount_percent : 0}% | العناصر: ${newItems.length}`;

    logAudit(
      req.currentUser.id, req.currentUser.name, auditAction, 'orders', req.params.id,
      `فاتورة #${newOrder ? newOrder.invoice_number : req.params.id} -> ${status || 'تعديل فاتورة'}`,
      JSON.stringify({ order: oldOrder, items: oldItems, summary: oldSummary }),
      JSON.stringify({ order: newOrder, items: newItems, summary: newSummary })
    );

    emitEvent('order:updated', { id: req.params.id, status });
    res.json({ ok: true });
  } catch(err) {
    console.error('Order update error:', err);
    res.status(500).json({ error: err.message || 'Failed to update order' });
  }
});

// DELETE Soft delete order
router.delete('/:id', (req, res) => {
  if (!checkPerm(req, 'delete_orders')) return res.status(403).json({ error: 'Forbidden' });
  const order = db.prepare('SELECT * FROM orders WHERE id=?').get(req.params.id);
  const items = db.prepare('SELECT oi.*, i.name as item_name FROM order_items oi LEFT JOIN items i ON oi.item_id=i.id WHERE oi.order_id=?').all(req.params.id);
  if (!order) return res.status(404).json({ error: 'Not found' });
  db.prepare('UPDATE orders SET is_deleted=1 WHERE id=?').run(req.params.id);
  if (order.table_id) {
    db.prepare('UPDATE "tables" SET status="empty", current_order_id=NULL WHERE id=?').run(order.table_id);
    emitEvent('table:updated', { table_id: order.table_id, status: 'empty', order_id: null });
  }
  logAudit(
    req.currentUser.id, req.currentUser.name, 'delete_order', 'orders', req.params.id,
    `حذف فاتورة #${order.invoice_number} (المبلغ: ${order.total})`,
    JSON.stringify({ order, items, summary: `المبلغ: ${order.total} | الخصم: ${order.discount_percent}%` }),
    'DELETED'
  );
  emitEvent('order:deleted', { id: req.params.id });
  res.json({ ok: true });
});

// POST Add Item to Order
router.post('/:id/items', (req, res) => {
  const { item_id, quantity, note, selected_modifiers } = req.body;
  const order = db.prepare('SELECT employee_id FROM orders WHERE id=?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (req.currentUser.role !== 'admin' && !req.currentUser.permissions.edit_orders && order.employee_id !== req.currentUser.id) {
    return res.status(403).json({ error: 'You can only modify your own orders' });
  }
  const modStr = Array.isArray(selected_modifiers) ? JSON.stringify(selected_modifiers) : (selected_modifiers || '[]');
  const product = db.prepare('SELECT id, price FROM items WHERE id=? AND active=1').get(item_id);
  const safeQuantity = Number(quantity);
  if (!product || !Number.isFinite(safeQuantity) || safeQuantity <= 0 || safeQuantity > 1000) return res.status(400).json({ error: 'Invalid order item' });
  const info = db.prepare('INSERT INTO order_items (order_id, item_id, quantity, note, price, discount_amount, selected_modifiers) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    req.params.id, product.id, safeQuantity, note || '', product.price, 0, modStr
  );
  recalcOrderTotal(req.params.id);
  logAudit(req.currentUser.id, req.currentUser.name, 'add_item', 'order_item', info.lastInsertRowid, `Added item to order #${req.params.id}`);
  emitEvent('order:items_changed', { order_id: req.params.id });
  res.json({ id: info.lastInsertRowid });
});

module.exports = router;
