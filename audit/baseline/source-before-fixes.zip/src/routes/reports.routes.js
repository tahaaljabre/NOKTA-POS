const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { getRequesterInfo, requirePermission } = require('../middleware/auth.middleware');
const { requireAuthenticated } = require('../middleware/auth.middleware');
router.use(requireAuthenticated);

router.get('/sales', requirePermission('reports'), (req, res) => {
  const requester = req.currentUser;
  let { from, to, employee_id } = req.query;
  const d1 = from || new Date().toISOString().split('T')[0];
  const d2 = to || d1;

  // Strict Data Isolation: If not admin and doesn't have full reports access, force employee_id to requester.id
  if (requester.role !== 'admin' && !requester.permissions.reports) {
    employee_id = requester.id;
  }

  let sql = "SELECT DATE(completed_at) as day, COUNT(*) as orders, SUM(total) as revenue FROM orders WHERE is_deleted=0 AND status='completed' AND DATE(completed_at) BETWEEN ? AND ?";
  const p = [d1, d2];
  if (employee_id) { sql += ' AND employee_id=?'; p.push(employee_id); }
  sql += ' GROUP BY day ORDER BY day';
  const daily = db.prepare(sql).all(...p);

  // By payment method
  let paySql = "SELECT payment_method, COUNT(*) as count, SUM(total) as total FROM orders WHERE is_deleted=0 AND status='completed' AND DATE(completed_at) BETWEEN ? AND ?";
  const pp = [d1, d2];
  if (employee_id) { paySql += ' AND employee_id=?'; pp.push(employee_id); }
  paySql += ' GROUP BY payment_method';
  const byPayment = db.prepare(paySql).all(...pp);

  // By employee
  let empSql = "SELECT employee_name, COUNT(*) as count, SUM(total) as total FROM orders WHERE is_deleted=0 AND status='completed' AND DATE(completed_at) BETWEEN ? AND ?";
  const ep = [d1, d2];
  if (employee_id) { empSql += ' AND employee_id=?'; ep.push(employee_id); }
  empSql += ' GROUP BY employee_id';
  const byEmployee = db.prepare(empSql).all(...ep);

  // Total
  let totSql = "SELECT COUNT(*) as total_orders, SUM(total) as total_revenue FROM orders WHERE is_deleted=0 AND status='completed' AND DATE(completed_at) BETWEEN ? AND ?";
  const tp = [d1, d2];
  if (employee_id) { totSql += ' AND employee_id=?'; tp.push(employee_id); }
  const totals = db.prepare(totSql).get(...tp);

  res.json({ from: d1, to: d2, daily, by_payment: byPayment, by_employee: byEmployee, totals });
});

router.get('/daily', requirePermission('reports'), (req, res) => {
  const { date } = req.query;
  const d = date || new Date().toISOString().split('T')[0];
  const orders = db.prepare("SELECT o.*, e.name as employee_name, e.name_en as employee_name_en FROM orders o LEFT JOIN employees e ON o.employee_id=e.id WHERE DATE(o.created_at)=? AND o.status='completed' AND o.is_deleted=0 ORDER BY o.id").all(d);
  
  let total = 0;
  orders.forEach(o => { total += o.total || 0; });
  total = Math.round(total * 100) / 100;

  const byEmployee = {};
  orders.forEach(o => {
    const name = o.employee_name || 'Unknown';
    if (!byEmployee[name]) byEmployee[name] = { count: 0, total: 0 };
    byEmployee[name].count++;
    byEmployee[name].total += o.total || 0;
    byEmployee[name].total = Math.round(byEmployee[name].total * 100) / 100;
  });
  
  res.json({ date: d, total_orders: orders.length, total_revenue: total, by_employee: byEmployee });
});

module.exports = router;
