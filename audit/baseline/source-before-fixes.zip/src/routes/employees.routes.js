const express = require('express');
const router = express.Router();
const { db, hashPin } = require('../database/db');
const { logAudit } = require('../middleware/audit.middleware');
const { getRequesterInfo, requireAdmin } = require('../middleware/auth.middleware');
const { requireAuthenticated } = require('../middleware/auth.middleware');
router.use(requireAuthenticated);

// GET Employees: Admins see all; non-admins only see sanitized public list or own profile
router.get('/', (req, res) => {
  const requester = getRequesterInfo(req);
  if (!requester) return res.status(401).json({ error: 'Unauthorized' });

  if (requester.role === 'admin' || requester.permissions.employees) {
    const rows = db.prepare('SELECT id, name, name_en, username, role, permissions, phone, default_floor, default_station, active, created_at FROM employees ORDER BY id').all();
    rows.forEach(r => {
      r.permissions = typeof r.permissions === 'string' ? JSON.parse(r.permissions || '{}') : (r.permissions || {});
    });
    return res.json(rows);
  }

  // Non-admin cashier/waiter: only sees active name list for display without sensitive pins/permissions
  const rows = db.prepare('SELECT id, name, name_en, role, default_floor, default_station FROM employees WHERE active=1').all();
  res.json(rows);
});

// Admin-only endpoints for employee management
router.post('/', requireAdmin, (req, res) => {
  const { name, name_en, pin, username, password, role, permissions, phone, default_floor, default_station } = req.body;
  if (!name || !pin) return res.status(400).json({ error: 'Name and PIN required' });
  const cleanUsername = username ? String(username).trim().toLowerCase() : null;
  if (cleanUsername && !/^[a-z0-9._-]{3,32}$/.test(cleanUsername)) return res.status(400).json({ error: 'Invalid username' });
  if (password && (typeof password !== 'string' || password.length < 6)) return res.status(400).json({ error: 'Password must contain at least 6 characters' });

  const floorVal = parseInt(default_floor) || 1;
  const stationVal = default_station || (role === 'waiter' ? 'waiter_mobile' : `cashier_floor${floorVal}`);

  const info = db.prepare('INSERT INTO employees (name, name_en, pin, username, password_hash, role, permissions, phone, default_floor, default_station) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(
    name, name_en || '', hashPin(pin), cleanUsername, password ? hashPin(password) : null, role || 'cashier', JSON.stringify(permissions || { pos: true }), phone || '', floorVal, stationVal
  );
  logAudit(req.currentUser.id, req.currentUser.name, 'create', 'employee', info.lastInsertRowid, `Created Employee: ${name} (${role}) - Floor ${floorVal}`);
  res.json({ id: info.lastInsertRowid });
});

router.put('/:id', requireAdmin, (req, res) => {
  const { name, name_en, pin, username, password, role, permissions, phone, default_floor, default_station, active } = req.body;
  const floorVal = default_floor !== undefined ? parseInt(default_floor) : undefined;
  const cleanUsername = username === undefined ? undefined : (username ? String(username).trim().toLowerCase() : null);
  if (cleanUsername && !/^[a-z0-9._-]{3,32}$/.test(cleanUsername)) return res.status(400).json({ error: 'Invalid username' });
  if (password && (typeof password !== 'string' || password.length < 6)) return res.status(400).json({ error: 'Password must contain at least 6 characters' });
  if (pin) {
    db.prepare(`
      UPDATE employees 
      SET name=COALESCE(?, name), 
          name_en=COALESCE(?, name_en), 
          pin=?,
          username=COALESCE(?, username),
          password_hash=COALESCE(?, password_hash),
          role=COALESCE(?, role), 
          permissions=COALESCE(?, permissions), 
          phone=COALESCE(?, phone),
          default_floor=COALESCE(?, default_floor),
          default_station=COALESCE(?, default_station),
          active=COALESCE(?, active) 
      WHERE id=?
    `).run(name, name_en, hashPin(pin), cleanUsername, password ? hashPin(password) : null, role, permissions ? JSON.stringify(permissions) : null, phone, floorVal, default_station, active, req.params.id);
  } else {
    db.prepare(`
      UPDATE employees 
      SET name=COALESCE(?, name),
          name_en=COALESCE(?, name_en), 
      username=COALESCE(?, username),
      password_hash=COALESCE(?, password_hash),
          role=COALESCE(?, role), 
          permissions=COALESCE(?, permissions), 
          phone=COALESCE(?, phone),
          default_floor=COALESCE(?, default_floor),
          default_station=COALESCE(?, default_station),
          active=COALESCE(?, active) 
      WHERE id=?
    `).run(name, name_en, cleanUsername, password ? hashPin(password) : null, role, permissions ? JSON.stringify(permissions) : null, phone, floorVal, default_station, active, req.params.id);
  }

  logAudit(req.currentUser.id, req.currentUser.name, 'update', 'employee', req.params.id, `Updated Employee: ${name || req.params.id}`);
  res.json({ ok: true });
});

router.delete('/:id', requireAdmin, (req, res) => {
  const targetId = parseInt(req.params.id);
  if (targetId === req.currentUser.id) {
    return res.status(400).json({ error: 'لا يمكنك حذف حسابك الحالي أثناء تسجيل الدخول' });
  }

  const emp = db.prepare('SELECT id, name, role FROM employees WHERE id=?').get(targetId);
  if (!emp) return res.status(404).json({ error: 'الموظف غير موجود' });

  // If permanent delete query parameter ?permanent=true is passed
  if (req.query.permanent === 'true') {
    db.prepare('DELETE FROM employees WHERE id=?').run(targetId);
    logAudit(req.currentUser.id, req.currentUser.name, 'delete', 'employee', targetId, `Deleted Employee permanently: ${emp.name} (${emp.role})`);
  } else {
    db.prepare('UPDATE employees SET active=0 WHERE id=?').run(targetId);
    logAudit(req.currentUser.id, req.currentUser.name, 'deactivate', 'employee', targetId, `Deactivated Employee: ${emp.name} (${emp.role})`);
  }
  res.json({ ok: true });
});

module.exports = router;
