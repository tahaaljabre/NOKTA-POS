const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { logAudit } = require('../middleware/audit.middleware');
const { requirePermission } = require('../middleware/auth.middleware');
const { requireAuthenticated } = require('../middleware/auth.middleware');
router.use(requireAuthenticated);

router.get('/', requirePermission('inventory'), (req, res) => {
  const rows = db.prepare(`
    SELECT inv.*, i.name as menu_item_name, i.price as menu_item_price
    FROM inventory inv
    LEFT JOIN items i ON inv.item_id = i.id
    ORDER BY inv.id DESC
  `).all();
  res.json(rows);
});

router.get('/alerts', requirePermission('inventory'), (req, res) => {
  const rows = db.prepare('SELECT * FROM inventory WHERE quantity <= min_alert_level').all();
  res.json(rows);
});

router.post('/', requirePermission('inventory'), (req, res) => {
  const { item_id, item_name, quantity, unit, min_alert_level, cost_unit } = req.body;
  const info = db.prepare(`
    INSERT INTO inventory (item_id, item_name, quantity, unit, min_alert_level, cost_unit, last_restocked_at)
    VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
  `).run(item_id || null, item_name, quantity || 0, unit || 'pcs', min_alert_level || 5, cost_unit || 0);

  logAudit(req.headers['x-employee-id'], req.headers['x-employee-name'], 'create', 'inventory', info.lastInsertRowid, `Added Stock: ${item_name} (${quantity} ${unit || 'pcs'})`);
  res.json({ id: info.lastInsertRowid });
});

router.post('/:id/adjust', requirePermission('inventory'), (req, res) => {
  const { quantity_change, type, notes } = req.body;
  const inv = db.prepare('SELECT * FROM inventory WHERE id=?').get(req.params.id);
  if (!inv) return res.status(404).json({ error: 'Inventory record not found' });

  const prevQty = parseFloat(inv.quantity) || 0;
  const change = parseFloat(quantity_change) || 0;
  const newQty = prevQty + change;

  db.prepare('UPDATE inventory SET quantity=?, last_restocked_at=datetime("now") WHERE id=?').run(newQty, req.params.id);
  db.prepare('INSERT INTO stock_logs (inventory_id, type, quantity, previous_qty, new_qty, employee_id, notes) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
    req.params.id, type || 'adjustment', change, prevQty, newQty, req.headers['x-employee-id'] || null, notes || ''
  );

  res.json({ ok: true, previous_qty: prevQty, new_qty: newQty });
});

module.exports = router;
