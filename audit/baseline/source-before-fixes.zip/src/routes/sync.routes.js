const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { logAudit } = require('../middleware/audit.middleware');
const { requirePermission } = require('../middleware/auth.middleware');
router.use(requirePermission('pos'));

router.post('/', (req, res) => {
  const { device_id, orders } = req.body || {};
  const syncedOrders = [];

  if (Array.isArray(orders)) {
    for (const o of orders) {
      try {
        // Atomic check: if offline_id already exists in db, don't re-insert duplicate
        if (o.offline_id) {
          const existing = db.prepare('SELECT id, invoice_number FROM orders WHERE offline_id=?').get(o.offline_id);
          if (existing) {
            syncedOrders.push({ offline_id: o.offline_id, id: existing.id, invoice_number: existing.invoice_number, already_synced: true });
            continue;
          }
        }

        // Get atomic next invoice number
        const row = db.prepare("SELECT value FROM settings WHERE key='next_invoice_number'").get();
        const invoiceNumber = row ? parseInt(row.value) || 1 : 1;
        db.prepare("UPDATE settings SET value=? WHERE key='next_invoice_number'").run(String(invoiceNumber + 1));

        const safeItems = Array.isArray(o.items) ? o.items.map(item => {
          const product = db.prepare('SELECT id, price FROM items WHERE id=? AND active=1').get(item.item_id);
          const quantity = Number(item.quantity);
          if (!product || !Number.isFinite(quantity) || quantity <= 0 || quantity > 1000) throw new Error('Invalid synced item');
          return { ...item, item_id: product.id, quantity, price: product.price };
        }) : [];
        if (!safeItems.length) throw new Error('Offline order has no items');
        const orderType = ['dine_in', 'takeaway', 'delivery'].includes(o.type) ? o.type : 'dine_in';
        const orderStatus = ['active', 'completed'].includes(o.status) ? o.status : 'completed';
        const discountPercent = Math.max(0, Math.min(100, Number(o.discount_percent) || 0));
        const discountAmount = Math.max(0, Number(o.discount_amount) || 0);
        const subtotal = safeItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const taxSetting = db.prepare("SELECT value FROM settings WHERE key='tax_rate'").get();
        const taxRate = taxSetting ? Math.max(0, Number(taxSetting.value) || 0) : 0;
        const afterDiscount = Math.max(0, subtotal * (1 - discountPercent / 100) - discountAmount);
        const serverTotal = Math.round((afterDiscount * (1 + taxRate / 100)) * 100) / 100;
        const info = db.prepare(`
          INSERT INTO orders (
            invoice_number, table_id, type, status, total, discount_percent, payment_method,
            note, employee_id, employee_name, synced, offline_id, station_id, floor, created_at, completed_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)
        `).run(
          invoiceNumber, o.table_id || null, orderType, orderStatus, serverTotal,
          discountPercent, o.payment_method || 'cash', o.note || '', req.currentUser.id, req.currentUser.name,
          o.offline_id || '', o.station_id || 'cashier_main', o.floor || 1,
          o.created_at || new Date().toISOString(), orderStatus === 'completed' ? (o.completed_at || new Date().toISOString()) : null
        );
        const orderId = info.lastInsertRowid;

        if (safeItems.length) {
          for (const item of safeItems) {
            const modStr = typeof item.selected_modifiers === 'string' ? item.selected_modifiers : JSON.stringify(item.selected_modifiers || item.modifiers || []);
            db.prepare('INSERT INTO order_items (order_id, item_id, quantity, note, price, discount_amount, selected_modifiers) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
              orderId, item.item_id, item.quantity || 1, item.note || '', item.price || 0, item.discount_amount || 0, modStr
            );
          }
        }

        if (o.table_id && orderStatus === 'active') {
          db.prepare('UPDATE "tables" SET status="occupied", current_order_id=? WHERE id=?').run(orderId, o.table_id);
        }

        syncedOrders.push({
          offline_id: o.offline_id || `local_${orderId}`,
          id: orderId,
          invoice_number: invoiceNumber,
          print_required: true,
          table_id: o.table_id,
          type: orderType,
          total: serverTotal,
          items: o.items
        });
      } catch (e) {
        console.error('Sync item error:', e.message);
      }
    }
  }

  db.prepare('INSERT INTO sync_log (device_id, last_sync) VALUES (?, datetime("now"))').run(device_id || 'unknown');
  logAudit(req.currentUser.id, req.currentUser.name, 'sync', 'orders', 0, `Synced ${syncedOrders.length} offline orders from device ${device_id || 'unknown'}`);
  res.json({ ok: true, synced: syncedOrders.length, syncedOrders });
});

module.exports = router;
