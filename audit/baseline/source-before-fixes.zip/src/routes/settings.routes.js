const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { logAudit } = require('../middleware/audit.middleware');
const { requireAuthenticated, requirePermission } = require('../middleware/auth.middleware');
router.use(requireAuthenticated);

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const settings = {};
  rows.forEach(r => { settings[r.key] = r.value; });
  res.json(settings);
});

router.put('/', requirePermission('settings'), (req, res) => {
  const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  Object.entries(req.body).forEach(([k, v]) => {
    stmt.run(k, String(v));
  });
  logAudit(req.headers['x-employee-id'], req.headers['x-employee-name'], 'update', 'settings', 0, 'Settings updated');
  res.json({ ok: true });
});

// Audit log endpoint (supports /api/audit and /api/settings/audit)
const handleAuditGet = (req, res) => {
  const { employee_id, action, date, limit } = req.query;
  let sql = 'SELECT * FROM audit_log WHERE 1=1';
  const p = [];
  if (employee_id) { sql += ' AND employee_id=?'; p.push(employee_id); }
  if (action) { sql += ' AND action=?'; p.push(action); }
  if (date) { sql += " AND DATE(created_at)=?"; p.push(date); }
  sql += ' ORDER BY id DESC';
  const lim = parseInt(limit) || 100;
  sql += ` LIMIT ${lim}`;
  res.json(db.prepare(sql).all(...p));
};

const os = require('os');
const config = require('../config/app.config');

// Network Information endpoint for multi-device connection
router.get('/network', requirePermission('settings'), (req, res) => {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        ips.push({ iface: name, address: net.address, url: `http://${net.address}:${config.port}` });
      }
    }
  }
  res.json({
    port: config.port,
    hostname: os.hostname(),
    localUrl: `http://localhost:${config.port}`,
    networkIps: ips,
    primaryUrl: ips.length > 0 ? ips[0].url : `http://localhost:${config.port}`
  });
});

module.exports = router;
module.exports.handleAuditGet = handleAuditGet;
