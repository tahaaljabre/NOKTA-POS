const path = require('path');

module.exports = {
  port: process.env.PORT || 3000,
  // POS tablets connect over the restaurant LAN; authentication protects the API.
  host: process.env.HOST || '0.0.0.0',
  dbDir: path.join(__dirname, '..', '..', 'data'),
  dbPath: path.join(__dirname, '..', '..', 'data', 'pos.sqlite'),
  publicDir: path.join(__dirname, '..', '..', 'public'),
  jwtSecret: process.env.JWT_SECRET || require('crypto').randomBytes(32).toString('hex'),
  defaultLanguage: 'ar',
  defaultCurrency: '฿'
};
